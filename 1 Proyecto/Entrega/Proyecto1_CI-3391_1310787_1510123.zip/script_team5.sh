#!/bin/bash

#	Jose Barrera, 15-10123
#	Maria Magallanes, 13-10787

# Corre el script que crea y llena la bd
sudo -u postgres psql -f bd_team5.sql